document.getElementById("joke-btn").addEventListener("click", fetchJoke);

async function fetchJoke() {
    try {
        const response = await fetch("/random-joke");
        const data = await response.json();
        if (response.ok) {
            document.getElementById("joke-container").innerHTML = `
                <p>${data.setup}</p>
                <p><strong>${data.punchline}</strong></p>
            `;
        } else {
            document.getElementById("joke-container").innerHTML = `
                <p>Error: ${data.error}</p>
            `;
        }
    } catch (error) {
        document.getElementById("joke-container").innerHTML = `
            <p>Failed to fetch joke: ${error.message}</p>
        `;
    }
}
