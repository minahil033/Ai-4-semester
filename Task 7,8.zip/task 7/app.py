from flask import Flask, jsonify, render_template
import requests

app = Flask(__name__)

@app.route('/random-joke', methods=['GET'])
def get_random_joke():
    try:
       
        response = requests.get('https://official-joke-api.appspot.com/random_joke')
        response.raise_for_status()
        joke = response.json()
        return jsonify({
            "setup": joke["setup"],
            "punchline": joke["punchline"]
        }), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Failed to fetch joke", "details": str(e)}), 500

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
